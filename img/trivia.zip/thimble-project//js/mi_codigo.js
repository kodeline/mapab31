/* 	
Archivo mi_codigo.js
En este archivo programaremos el código correspondiente
al juego de Trivia.
 */

let	indice_pregunta_actual;
let	total_puntos;

indice_pregunta_actual = 0;
total_puntos = 10;

const nombre_alumno = "Nombre Alumno";
const maximo_preguntas_por_jugada = 3;
const puntos_resultado_bien = 2;

console.log(nombre_alumno);
console.log(maximo_preguntas_por_jugada);
console.log(puntos_resultado_bien);
console.log(indice_pregunta_actual);
console.log(total_puntos);